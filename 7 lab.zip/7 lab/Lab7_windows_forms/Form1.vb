﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        this.FormBorderStyle = FormBorderStyle.Sizable;

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        this.Size = New Size(300, 500);
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        this.Opacity = 1;
    End Sub
End Class
